package antonioSanchezExamenPOO;

public class Estudiante extends Miembro{
	private Asignatura[] asignaturas;
	
	public Estudiante(String nombre, String DNI, Asignatura asignatura1, Asignatura asignatura2, Asignatura asignatura3) {
		super(nombre, DNI);
		asignaturas = new Asignatura[3];
		if (asignatura1 != null) {
		asignaturas[0] = asignatura1;
		}
		if (asignatura2 != null) {
		asignaturas[1] = asignatura2;
		}
		if (asignatura3 != null) {
		asignaturas[2] = asignatura3;
		}
	}
		
	public void setAsignatura(int i, Asignatura asignatura) {
		if (asignatura != null) {
			asignaturas[i] = asignatura;
			}
	}
	
	public String getAsignatura(int i) {
		return asignaturas[i].toString();
	}
	@Override
	public void saludar() {
		System.out.println("�Hola!");
	}
	
	@Override
	public String toString() {
		String str = "El alumno " + this.getNombre() + ", cuyo DNI es " + this.getDNI() + " cursa en las asignaturas ";
		int i = 0;
		do {
			str += asignaturas[i].toString() + ", ";
			i++;
		}while (i < asignaturas.length);
		return str;
	}
}
