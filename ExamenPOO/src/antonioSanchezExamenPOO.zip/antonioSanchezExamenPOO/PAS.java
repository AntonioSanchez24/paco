package antonioSanchezExamenPOO;

public class PAS extends Personal{
	private Especialidad especialidad;
	
	public PAS(String nombre, String DNI, Especialidad especialidad) {
		super(nombre, DNI);
		this.especialidad = especialidad;
	}
	public PAS(int salario, String nombre, String DNI, Especialidad especialidad) {
		super(salario, nombre, DNI);
		if(especialidad != null) {
		this.especialidad = especialidad;
		}
	}
	
	public void setEspecialidad(Especialidad especialidad) {
		if(especialidad != null) {
			this.especialidad = especialidad;
			}
	}
	
	public String getEspecialidad() {
		if (this.especialidad.equals(Especialidad.Contratos)) {
			return "Contratos";
		} else if (this.especialidad.equals(Especialidad.Nominas)) {
			return "N�minas";
		} else if (this.especialidad.equals(Especialidad.GDA)) {
			return "Gesti�n de Aulas";
		} else if (this.especialidad.equals(Especialidad.CE)) {
			return "Cursos Extraordinarios";
		} else {
			return "No especificado";
		}
	}
	
	public String toString() {
		String str = "El miembro del personal de administraci�n y servicios " + this.getNombre() + ", cuyo DNI es " 
	+ this.getDNI() + " se especializa en " + this.getEspecialidad() + ". Su salario actual es " + this.getSalario() + ".";
		return str;
	}
}
