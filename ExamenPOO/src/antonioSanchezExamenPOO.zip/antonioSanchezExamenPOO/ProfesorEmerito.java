package antonioSanchezExamenPOO;

public class ProfesorEmerito extends Personal implements Conferenciantes {
	
	private Asignatura[] asignaturas;
	private int numeroCharlas;
	private static int numeroCharlasTotales;
	
	public ProfesorEmerito(String nombre, String DNI, Asignatura asignatura1, Asignatura asignatura2) {
		super(nombre, DNI);
		asignaturas = new Asignatura[2];
		if (asignatura1 != null) {
			asignaturas[0] = asignatura1;
			}
		if (asignatura2 != null) {
			asignaturas[1] = asignatura2;
			}
	}
	public ProfesorEmerito(int salario, String nombre, String DNI, Asignatura asignatura1, Asignatura asignatura2) {
		super(salario, nombre, DNI);
		asignaturas = new Asignatura[2];
		if (asignatura1 != null) {
			asignaturas[0] = asignatura1;
			}
		if (asignatura2 != null) {
			asignaturas[1] = asignatura2;
			}
	}
	
	public void setAsignatura(int i, Asignatura asignatura) {
		if (asignatura != null) {
			asignaturas[i] = asignatura;
			}
	}
	
	public String getAsignatura(int i) {
		return asignaturas[i].toString();
	}
	
	public int getNumeroCharlas() {
		return numeroCharlas;
	}
	public void setNumeroCharlas(int numeroCharlas) {
		this.numeroCharlas = numeroCharlas;
	}
	public static int getNumeroCharlasTotales() {
		return numeroCharlasTotales;
	}
	public static void setNumeroCharlasTotales(int numeroCharlasTotales) {
		ProfesorEmerito.numeroCharlasTotales = numeroCharlasTotales;
	}
	@Override
	public void darCharla() {
		System.out.println("Hoy vengo a hablar de " + asignaturas[0].getTitulo() + " y de " + asignaturas[1].getTitulo());
		this.setNumeroCharlas(this.getNumeroCharlas() + 1);
		setNumeroCharlasTotales(getNumeroCharlasTotales() + 1);
	}
	
	@Override	
	public String toString() {
		String str = "El profesor em�rito " + this.getNombre() + ", cuyo DNI es " + this.getDNI() + " da charlas sobre las asignaturas ";
		int i = 0;
		do {
			str += asignaturas[i].toString() + ", ";
			i++;
		}while (i < asignaturas.length);
		str += ". Su salario actual es " + this.getSalario() + ".";
		return str;
	}
}
