package antonioSanchezExamenPOO;

public class Profesor extends Personal {
	private Asignatura[] asignaturas;
	
	public Profesor(String nombre, String DNI, Asignatura asignatura1, Asignatura asignatura2) {
		super(nombre, DNI);
		asignaturas = new Asignatura[2];
		if (asignatura1 != null) {
			asignaturas[0] = asignatura1;
			}
		if (asignatura2 != null) {
			asignaturas[1] = asignatura2;
			}
	}
	public Profesor(int salario, String nombre, String DNI, Asignatura asignatura1, Asignatura asignatura2) {
		super(salario, nombre, DNI);
		asignaturas = new Asignatura[2];
		if (asignatura1 != null) {
			asignaturas[0] = asignatura1;
			}
		if (asignatura2 != null) {
			asignaturas[1] = asignatura2;
			}
	}
	
	public void setAsignatura(int i, Asignatura asignatura) {
		if (asignatura != null) {
			asignaturas[i] = asignatura;
			}
	}
	
	public String getAsignatura(int i) {
		return asignaturas[i].toString();
	}
	
	public String toString() {
		String str = "El profesor " + this.getNombre() + ", cuyo DNI es " + this.getDNI() + " imparte las asignaturas ";
		int i = 0;
		do {
			str += asignaturas[i].toString() + ", ";
			i++;
		}while (i < asignaturas.length);
		str += ". Su salario actual es " + this.getSalario() + ".";
		return str;
	}
}
