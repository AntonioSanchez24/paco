package antonioSanchezExamenPOO;

public enum Especialidad {
	Contratos,
	Nominas,
	GDA, //Gesti�n de Aulas
	CE, //Cursos Extraordinarios
}
