package antonioSanchezExamenPOO;

public interface Conferenciantes {
	public void darCharla();
}
